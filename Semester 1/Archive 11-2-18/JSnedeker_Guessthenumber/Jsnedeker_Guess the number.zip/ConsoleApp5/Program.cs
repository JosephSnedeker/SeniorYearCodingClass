﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    class Program
    {
        static void Main(string[] args)
        {
            //This code will generate a random number and ask the user for input to try and guess the number
            //create a random int variable that will try to be guessed
            //create a variable that will count up each time the following loop is ran starting at 1
            //create a while loop that will go until number is guessed correctly
                //ask user for input
                //create a user input variable 
                //if user input equals the random int
                    //then print congradulations and print the value of the counting variable to show the number of guesses  and end the loop
                //else if user value is greater than the random int
                    //print incorrect too high, add to the counting variable, and return to the top of the loop
                //else if user value is lower than the random int
                    //print incorrect too low, add to the counting variable, and return to the top of the loop
               
        }
    }
}
